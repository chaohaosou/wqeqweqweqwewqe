<?php
 $url= htmlspecialchars($_GET['url']);
if($url=="")die ("未传入链接");
$Text="超值活动惊喜,活动多多";
	include "TopSdk.php";
$c=new TopClient;
$c->appkey = "23417058";
$c->secretKey = "33cda456bf7981ccfa22e9262ebe4649";
    $req = new TbkTpwdCreateRequest;	
	$req->setText ($Text);	
	$req->setUrl ($url);
	$req->setLogo ("“https://img.alicdn.com/tps/i3/T1OjaVFl4dXXa.JOZB-114-114.png");
	$resp = $c->execute($req);

$tkl=$resp->data->model;
if($tkl=="")   die("口令生成为空".$url);  
echo $tkl;
exit;