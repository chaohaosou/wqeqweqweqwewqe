<?php

/**
 * data
 * @author auto create
 */
class Data
{
	
	/** 
	 * 邀请码
	 **/
	public $inviter_code;	
}
?>